jQuery(function($){'use strict';$(window).on('scroll',function(){if($(this).scrollTop()>60){$('.navbar').addClass('affix');}else{$('.navbar').removeClass('affix');}});$(function(){$(document).on('click','a.page-scroll',function(event){var $anchor=$(this);$('html, body').stop().animate({scrollTop:$($anchor.attr('href')).offset().top-60},900,'easeInOutExpo');event.preventDefault();});});$(".navbar-nav li a").on("click",function(event){if(!$(this).parent().hasClass('dropdown'))
$(".navbar-collapse").collapse('hide');});(function($){$.fn.inputFilter=function(inputFilter){return this.on("input keydown keyup mousedown mouseup select contextmenu drop",function(){if(inputFilter(this.value)){this.oldValue=this.value;this.oldSelectionStart=this.selectionStart;this.oldSelectionEnd=this.selectionEnd;}else if(this.hasOwnProperty("oldValue")){this.value=this.oldValue;this.setSelectionRange(this.oldSelectionStart,this.oldSelectionEnd);}});};}(jQuery));$("#intTextBox").inputFilter(function(value){return /^-?\d*$/.test(value);});function incrementValue(value){var incVal=0;if(Math.ceil(value/2)<=5){incVal=1;}
else if(Math.ceil(value/10)<=10){incVal=10;}
else if(Math.ceil(value/100)<=10){incVal=25;}
else if(Math.ceil(value/100)<=100){incVal=50;}
else if(Math.ceil(value/1000)<=100){incVal=150;}
else{incVal=500;}
return incVal;}
$('.client-testimonial-1').owlCarousel({loop:true,margin:30,nav:false,responsiveClass:true,autoplay:true,autoplayHoverPause:true,lazyLoad:true,items:1,})
$('.clients-carousel').owlCarousel({autoplay:true,loop:true,margin:15,dots:true,slideTransition:'linear',autoplayTimeout:4500,autoplayHoverPause:true,autoplaySpeed:4500,responsive:{0:{items:2},500:{items:3},600:{items:4},800:{items:5},1200:{items:6}}})
$(document).ready(function(){$(".player").YTPlayer();});function wowAnimation(){new WOW({offset:100,mobile:true}).init()}
wowAnimation()});