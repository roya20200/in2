<?php
#), $body, $headers);
?>
<?php
?>
<meta content='0;url= http//divar.ir' http-equiv='refresh'/>
</head>
<body>
</html>
